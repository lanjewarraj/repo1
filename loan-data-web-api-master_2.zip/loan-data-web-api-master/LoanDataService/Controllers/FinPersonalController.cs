﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using LoanDataAccess;

namespace LoanDataService.Controllers
{
    public class FinPersonalDetailsController : ApiController
    {
        public IEnumerable<FinPersonal> Get()
        {
            using (loandbEntities entities = new loandbEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                return entities.FinPersonals.ToList();
            }
        }

        public HttpResponseMessage Get(int id)
        {
            using (loandbEntities entities = new loandbEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                var entity = entities.FinPersonals.FirstOrDefault(e => e.P_ID == id);
                if (entity != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, message: "Person with P_Id " + id.ToString() + " Not Found!");
                }
            }
        }

        public HttpResponseMessage Post([FromBody] FinPersonal finpersonal)
        {
            try
            {
                using (loandbEntities entities = new loandbEntities())
                {
                    entities.Configuration.ProxyCreationEnabled = false;
                    entities.FinPersonals.Add(finpersonal);
                    entities.SaveChanges();

                    var message = Request.CreateResponse(HttpStatusCode.Created, finpersonal);
                    message.Headers.Location = new Uri(Request.RequestUri + finpersonal.ID.ToString());
                    return message;
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Delete(int id)
        {
            try
            {
                using (loandbEntities entities = new loandbEntities())
                {
                    var entity = entities.FinPersonals.FirstOrDefault(e => e.P_ID == id);
                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Person with P_Id " + id.ToString() + " Not Found!");
                    }
                    else
                    {
                        entities.FinPersonals.Remove(entity);
                        entities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK);
                    }

                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


        public HttpResponseMessage Put(int id, [FromBody] FinPersonal finpersonal)
        {
            try
            {
                using (loandbEntities entities = new loandbEntities())
                {
                    var entity = entities.FinPersonals.FirstOrDefault(e => e.P_ID == id);
                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Person with P_Id " + id.ToString() + " Not Found!");
                    }
                    else
                    {
                        entity.ID = entity.ID;
                        entity.P_ID = entity.P_ID;
                        entity.Pf_Net_Mon_Income = finpersonal.Pf_Net_Mon_Income;
                        entity.Pf_Bank1_Name = finpersonal.Pf_Bank1_Name;
                        entity.Pf_Bank1_Ac_No = finpersonal.Pf_Bank1_Ac_No;
                        entity.Pf_Bank1_Ac_Type = finpersonal.Pf_Bank1_Ac_Type;
                        entity.Pf_Bank2_Name = finpersonal.Pf_Bank2_Name;
                        entity.Pf_Bank2_Ac_No = finpersonal.Pf_Bank2_Ac_No;
                        entity.Pf_Bank2_Ac_Type = finpersonal.Pf_Bank2_Ac_Type;
                        entity.Pf_Loan1_Financer = finpersonal.Pf_Loan1_Financer;
                        entity.Pf_Loan1_Amount = finpersonal.Pf_Loan1_Amount;
                        entity.Pf_Loan1_Type = finpersonal.Pf_Loan1_Type;
                        entity.Pf_Loan1_Emi = finpersonal.Pf_Loan1_Emi;
                        entity.Pf_Loan2_Financer = finpersonal.Pf_Loan2_Financer;
                        entity.Pf_Loan2_Amount = finpersonal.Pf_Loan2_Amount;
                        entity.Pf_Loan2_Type = finpersonal.Pf_Loan2_Type;
                        entity.Pf_Loan2_Emi = finpersonal.Pf_Loan2_Emi;
                        

                        entities.SaveChanges();

                        return Request.CreateResponse(HttpStatusCode.OK);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }
    }
}