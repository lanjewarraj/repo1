using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KycDataAccess;

namespace FinGoldHome.Controllers
{
    public class FinGoldHomeControllers : ApiController
    {

        public IEnumerable<FinGoldHome> Get()
        {
            using (TestKYCEntities entities = new TestKYCEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                return entities.FinGoldHomes.ToList();
            }
        }

        public HttpResponseMessage Get(int id)
        {
            using (TestKYCEntities entities = new TestKYCEntities())
            {
                entities.Configuration.ProxyCreationEnabled = false;
                var entity = entities.FinGoldHomes.FirstOrDefault(e => e.I_ID == id);
                if (entity != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, entity);
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.NotFound, message: "FinGoldHome detail with Id " + id.ToString() + " Not Found!");
                }
            }
        }

        public HttpResponseMessage Post([FromBody] FinGoldHome fingoldhome)
        {
            try
            {
                using (TestKYCEntities entities = new TestKYCEntities())
                {
                    entities.Configuration.ProxyCreationEnabled = false;
                    entities.FinGoldHomes.Add(fingoldhome);
                    entities.SaveChanges();

                    var message = Request.CreateResponse(HttpStatusCode.Created, fingoldhome);
                    message.Headers.Location = new Uri(Request.RequestUri + fingoldhome.I_ID.ToString());
                    return message;
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Delete(int id)
        {
            try
            {
                using (TestKYCEntities entities = new TestKYCEntities())
                {
                    var entity = entities.FinGoldHomes.FirstOrDefault(e => e.I_ID == id);
                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "FinGoldHome details with Id " + id.ToString() + " Not Found!");
                    }
                    else
                    {
                        entities.FinGoldHomes.Remove(entity);
                        entities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Put(int id, [FromBody]FinGoldHome fingoldhome)
        {
            try
            {
                using (TestKYCEntities entities = new TestKYCEntities())
                {
                    var entity = entities.FinGoldHomes.FirstOrDefault(e => e.I_ID == id);
                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "FinGoldHome details with Id " + id.ToString() + " Not Found!");
                    }
                    else
                    {
                        entity.P_ID = fingoldhome.P_ID;
                        entity.Fin_Status = fingoldhome.Fin_Status;
                        entity.Fin_Inc_Gross = fingoldhome.Fin_Inc_Gross;
                        entity.Fin_Inc_Net = fingoldhome.Fin_Inc_Net;
                        entity.Fin_Inc_Othr = fingoldhome.Fin_Inc_Othr;
                        entity.Fin_Inc_Total = fingoldhome.Fin_Inc_Total;
                        entity.Fin_Bank1_Name = fingoldhome.Fin_Bank1_Name;
                        entity.Fin_Bank1_Branch = fingoldhome.Fin_Bank1_Branch;
                        entity.Fin_Bank1_Ac_Type = fingoldhome.Fin_Bank1_Ac_Type;
                        entity.Fin_Bank1_Ac_No = fingoldhome.Fin_Bank1_Ac_No;
                        entity.Fin_Bank2_Name = fingoldhome.Fin_Bank2_Name;
                        entity.Fin_Bank2_Ac_Type = fingoldhome.Fin_Bank2_Branch ;
                        entity.Fin_Bank2_Ac_No = fingoldhome.Fin_Bank2_Ac_No;
                        entity.Fin_Loan1_Bank = fingoldhome.Fin_Loan1_Bank;
                        entity.Fin_Loan1_Type = fingoldhome.Fin_Loan1_Type;
                        entity.Fin_Loan1_Amount = fingoldhome.Fin_Loan1_Amount;
                        entity.Fin_Loan1_Emi = fingoldhome.Fin_Loan1_Emi;
                        entity.Fin_Loan1_Tenure = fingoldhome.Fin_Loan1_Tenure;
                        entity.Fin_Loan1_Emi_No = fingoldhome.Fin_Loan1_Emi_No;
                        entity.Fin_Loan2_Bank = fingoldhome.Fin_Loan2_Bank;
                        entity.Fin_Loan2_Type = fingoldhome.Fin_Loan2_Type;
                        entity.Fin_Loan2_Amount = fingoldhome.Fin_Loan2_Amount;
                        entity.Fin_Loan2_Tenure = fingoldhome.Fin_Loan2_Tenure;
                        entity.Fin_Loan2_Emi_No = fingoldhome.Fin_Loan2_Emi_No;
                        entity.Fin_Deposits_Inv = fingoldhome.Fin_Deposits_Inv;
                        entity.Fin_Shares_Inv = fingoldhome.Fin_Shares_Inv;
                        entity.Fin_Insurance_Inv = fingoldhome.Fin_Insurance_Inv;
                        entity.Fin_Mutual_Funds_Inv = fingoldhome.Fin_Mutual_Funds_Inv;
                        entity.Fin_Others_Inv = fingoldhome.Fin_Others_Inv;
                        entity.Fin_Total_Inv = fingoldhome.Fin_Total_Inv;
                        
                        entities.SaveChanges();

                        return Request.CreateResponse(HttpStatusCode.OK);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

    }
}

